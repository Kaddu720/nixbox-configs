static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#c7c4c4", "#191919" },
	[SchemeSel] = { "#c7c4c4", "#aa7264" },
	[SchemeOut] = { "#c7c4c4", "#563ea9" },
};
