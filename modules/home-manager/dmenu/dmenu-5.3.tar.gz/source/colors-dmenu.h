static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#e0def4", "#191724" },
	[SchemeSel] = { "#191724", "#ebbcba" },
	[SchemeOut] = { "#e0def4", "#403d52" },
};
